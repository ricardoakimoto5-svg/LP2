﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class ex4 : Form
    {
        public ex4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            string[] nomes = new string[10];
            int[] len = new int[10];
            string aux = "";
            string saida = "";
            for (int count = 0; count < nomes.GetLength(0); count++)
            {
                aux = Interaction.InputBox($"Nome da pessoa n{count + 1} :", "entrada de dados");
                if (aux == "") { count--; }
                else
                {
                    nomes[count] = aux;
                    len[count] = aux.Replace(" ", "").Length;
                    saida += $"{nomes[count]} tem {len[count]} caracteres\n";
                }
            }
            richTextBox1.Text = saida;
        }
    }
}
