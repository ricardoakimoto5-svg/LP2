﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
        
    {
        double L1, L2, L3;

        private void TxTLado2_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(TxTLado2.Text, out L2))
            {
                errorProvider2.SetError(TxTLado2, "Entrada invalida");
                TxTLado2.Focus();   
            }
        }

        private void TxTLado3_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(TxTLado3.Text, out L3))
            {
                errorProvider3.SetError(TxTLado3, "Entrada invalida");
                TxTLado3.Focus();
            }
        }

        private void BntConfim_Click(object sender, EventArgs e)
        {
            if ((L1<L2+L3) && (L1>Math.Abs(L2-L3) && (L2<L1+L3) && (L2>Math.Abs(L1-L3) && (L3<L1+L2) && (L3>Math.Abs(L1-L2)))))                
            {

                if ((L1 == L2)  && (L2 == L3) )
                {
                    TxTResultado.Text="Triangulo equilatero";
                }

                else if( (L1 == L2) || (L1==L3) || (L2==L3))
                {
                    TxTResultado.Text="Triangul isosceles";
                }

                else
                {
                    TxTResultado.Text = "Triangulo escaleno";
                }
                    

            }
            else
                MessageBox.Show("Não forma triangulo");




        }

        private void BntLimpar_Click(object sender, EventArgs e)
        {
            TxTLado1.Clear();
            TxTLado2.Clear();
            TxTLado3.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TxTLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxTLado1.Text, out L1 ))
            {
                errorProvider1.SetError(TxTLado1, "Entrada invalida");
                TxTLado1.Focus();

            }
                
            
        }
    }
}
