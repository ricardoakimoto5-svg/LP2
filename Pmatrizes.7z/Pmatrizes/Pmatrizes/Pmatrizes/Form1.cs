﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[]Vetor = new int[20];
            string auxiliar = "";
            for (int i= 0; i< Vetor.Length; i++) 
            {
                auxiliar = Interaction.InputBox("Digite números", "Entradas de Dados");

                if(!int.TryParse(auxiliar, out Vetor[i])) 
                {
                    MessageBox.Show("valor invalido");
                    i--;
                }

            }
            Array.Reverse(Vetor);

            auxiliar = "";
            auxiliar = string.Join("\n", Vetor);
            MessageBox.Show(auxiliar);

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
           ArrayList Lista = new ArrayList() {"Ana"," André", "Beatriz", "Camila", "João", "Joana","Otávio",
"Marcelo", "Pedro", "Thais"};

            Lista.Remove("Otavio");

            string anix = "";
            foreach (string s in Lista)
            {
                anix += s + "";
            }
            MessageBox.Show(anix);
         
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            double [,] notas = new double[20,3];
            string auxiliar = "";
            double media = 0;
            string saída = "";

            for (int i = 0; i < 20;  i++) 
            {
                media = 0;
              for (int j = 0; j < 3; j++) 
                {

                    auxiliar = Interaction.InputBox("Digite a nota", "Entradas de Dados");

                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("valor invalido");
                        j--;
                    }
                    else
                        media += notas[i, j];

                }
                media = media / 3;
                    saída += $"aluno {i + 1}media{media}";

                MessageBox.Show(saída);
            
            }
            

        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            string[] vetor1 = new string[10];
            int[] vetor2 = new int[10];
            string auxiliar = "";


        }
    }
}
