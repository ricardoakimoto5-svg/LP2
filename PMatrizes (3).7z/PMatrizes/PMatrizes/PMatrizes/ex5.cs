﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class ex5 : Form
    {
        public ex5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int n = 3; 
            
            // MEU RA É 0030482511023
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostas = new char[n, 10];
            
            for (int count = 0; count < respostas.GetLength(0); count++)
            {
                for (int count2 = 0; count2 < respostas.GetLength(1); count2++)
                {
                    respostas[count, count2] = Convert.ToChar(Interaction.InputBox($"Resposta do aluno{count} do exercicio {count2}", "entrada de dados"));
                }
            }
        }
    }
}
