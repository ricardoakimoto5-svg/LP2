﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace Pfilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double [,] filme = new double[2, 2];
            double media1;
            double media2;


            for (int i = 0; i < filme.GetLength(0); i++) 
            {
                for (int j = 0; j < filme.GetLength(1); j++) 
                {

                    filme[i,j] = Convert.ToChar(Interaction.InputBox($"Pessoa {i} Nota  do filme {j}"));  

                }
                
            
            }
            media1 = (filme[0, 0] + filme[1, 0]) / 2;
            media2 = (filme[1, 0] + filme[1, 1]) / 2;


            MessageBox.Show($"A media do filme 1 e{media1}");
            MessageBox.Show($"A media do filme 2 e{media2}");


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
