﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[]Vetor = new int[20];
            string auxiliar = "";
            for (int i= 0; i< Vetor.Length; i++) 
            {
                auxiliar = Interaction.InputBox("Digite números", "Entradas de Dados");

                if(!int.TryParse(auxiliar, out Vetor[i])) 
                {
                    MessageBox.Show("valor invalido");
                    i--;
                }

            }
            Array.Reverse(Vetor);

            auxiliar = "";
            auxiliar = string.Join("\n", Vetor);
            MessageBox.Show(auxiliar);

        }

        private void Btn2_Click(object sender, EventArgs e)
        {
           ArrayList Lista = new ArrayList() {"Ana"," André", "Beatriz", "Camila", "João", "Joana","Otávio",
"Marcelo", "Pedro", "Thais"};

            Lista.Remove("Otavio");

            string anix = "";
            foreach (string s in Lista)
            {
                anix += s + "";
            }
            MessageBox.Show(anix);
         
        }
    }
}
