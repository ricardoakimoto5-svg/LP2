﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LD1 = new System.Windows.Forms.Label();
            this.LD2 = new System.Windows.Forms.Label();
            this.LD3 = new System.Windows.Forms.Label();
            this.TxTLado1 = new System.Windows.Forms.TextBox();
            this.TxTLado2 = new System.Windows.Forms.TextBox();
            this.TxTLado3 = new System.Windows.Forms.TextBox();
            this.BntConfim = new System.Windows.Forms.Button();
            this.BntLimpar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TxTResultado = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // LD1
            // 
            this.LD1.AutoSize = true;
            this.LD1.Location = new System.Drawing.Point(12, 44);
            this.LD1.Name = "LD1";
            this.LD1.Size = new System.Drawing.Size(58, 20);
            this.LD1.TabIndex = 0;
            this.LD1.Text = "Lado 1";
            // 
            // LD2
            // 
            this.LD2.AutoSize = true;
            this.LD2.Location = new System.Drawing.Point(12, 97);
            this.LD2.Name = "LD2";
            this.LD2.Size = new System.Drawing.Size(58, 20);
            this.LD2.TabIndex = 1;
            this.LD2.Text = "Lado 2";
            // 
            // LD3
            // 
            this.LD3.AutoSize = true;
            this.LD3.Location = new System.Drawing.Point(16, 161);
            this.LD3.Name = "LD3";
            this.LD3.Size = new System.Drawing.Size(58, 20);
            this.LD3.TabIndex = 2;
            this.LD3.Text = "Lado 3\r\n";
            // 
            // TxTLado1
            // 
            this.TxTLado1.Location = new System.Drawing.Point(76, 44);
            this.TxTLado1.Name = "TxTLado1";
            this.TxTLado1.Size = new System.Drawing.Size(222, 26);
            this.TxTLado1.TabIndex = 3;
            this.TxTLado1.Validated += new System.EventHandler(this.TxTLado1_Validated);
            // 
            // TxTLado2
            // 
            this.TxTLado2.Location = new System.Drawing.Point(76, 97);
            this.TxTLado2.Name = "TxTLado2";
            this.TxTLado2.Size = new System.Drawing.Size(222, 26);
            this.TxTLado2.TabIndex = 4;
            this.TxTLado2.Validated += new System.EventHandler(this.TxTLado2_Validated);
            // 
            // TxTLado3
            // 
            this.TxTLado3.Location = new System.Drawing.Point(76, 161);
            this.TxTLado3.Name = "TxTLado3";
            this.TxTLado3.Size = new System.Drawing.Size(222, 26);
            this.TxTLado3.TabIndex = 5;
            this.TxTLado3.Validated += new System.EventHandler(this.TxTLado3_Validated);
            // 
            // BntConfim
            // 
            this.BntConfim.Location = new System.Drawing.Point(522, 44);
            this.BntConfim.Name = "BntConfim";
            this.BntConfim.Size = new System.Drawing.Size(135, 67);
            this.BntConfim.TabIndex = 6;
            this.BntConfim.Text = "Confirmar";
            this.BntConfim.UseVisualStyleBackColor = true;
            this.BntConfim.Click += new System.EventHandler(this.BntConfim_Click);
            // 
            // BntLimpar
            // 
            this.BntLimpar.Location = new System.Drawing.Point(522, 120);
            this.BntLimpar.Name = "BntLimpar";
            this.BntLimpar.Size = new System.Drawing.Size(135, 67);
            this.BntLimpar.TabIndex = 7;
            this.BntLimpar.Text = "Limpar";
            this.BntLimpar.UseVisualStyleBackColor = true;
            this.BntLimpar.Click += new System.EventHandler(this.BntLimpar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Resultado";
            // 
            // TxTResultado
            // 
            this.TxTResultado.Enabled = false;
            this.TxTResultado.Location = new System.Drawing.Point(111, 266);
            this.TxTResultado.Name = "TxTResultado";
            this.TxTResultado.Size = new System.Drawing.Size(218, 26);
            this.TxTResultado.TabIndex = 9;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 450);
            this.Controls.Add(this.TxTResultado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BntLimpar);
            this.Controls.Add(this.BntConfim);
            this.Controls.Add(this.TxTLado3);
            this.Controls.Add(this.TxTLado2);
            this.Controls.Add(this.TxTLado1);
            this.Controls.Add(this.LD3);
            this.Controls.Add(this.LD2);
            this.Controls.Add(this.LD1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LD1;
        private System.Windows.Forms.Label LD2;
        private System.Windows.Forms.Label LD3;
        private System.Windows.Forms.TextBox TxTLado1;
        private System.Windows.Forms.TextBox TxTLado2;
        private System.Windows.Forms.TextBox TxTLado3;
        private System.Windows.Forms.Button BntConfim;
        private System.Windows.Forms.Button BntLimpar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxTResultado;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}

