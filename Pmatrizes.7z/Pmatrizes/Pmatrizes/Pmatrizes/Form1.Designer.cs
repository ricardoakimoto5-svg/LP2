﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn1 = new System.Windows.Forms.Button();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(83, 32);
            this.Btn1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(143, 123);
            this.Btn1.TabIndex = 0;
            this.Btn1.Text = "Exercicio 1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(230, 32);
            this.Btn2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(143, 123);
            this.Btn2.TabIndex = 1;
            this.Btn2.Text = "Exercicio 2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(83, 159);
            this.Btn3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(143, 123);
            this.Btn3.TabIndex = 2;
            this.Btn3.Text = "Exercicio 3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // Btn4
            // 
            this.Btn4.Location = new System.Drawing.Point(230, 159);
            this.Btn4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(143, 123);
            this.Btn4.TabIndex = 3;
            this.Btn4.Text = "Exercicio 4";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // Btn5
            // 
            this.Btn5.Location = new System.Drawing.Point(377, 94);
            this.Btn5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(143, 123);
            this.Btn5.TabIndex = 4;
            this.Btn5.Text = "Exercicio 5";
            this.Btn5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 373);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button Btn5;
    }
}

